VALUES = (0, 1)
