from receipts import VALUES


def test_receipt():
    assert VALUES[0] == 1, "first receipt check"
    assert VALUES[1] == 1, "second receipt check"


def test_stable():
    assert len(VALUES) == 2
